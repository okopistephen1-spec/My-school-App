---
name: SmoothPlays Atmospheric Dark
colors:
  surface: '#10131c'
  surface-dim: '#10131c'
  surface-bright: '#363943'
  surface-container-lowest: '#0b0e17'
  surface-container-low: '#181b25'
  surface-container: '#1c1f29'
  surface-container-high: '#272a34'
  surface-container-highest: '#32343f'
  on-surface: '#e0e2ef'
  on-surface-variant: '#c1c6d6'
  inverse-surface: '#e0e2ef'
  inverse-on-surface: '#2d303a'
  outline: '#8b91a0'
  outline-variant: '#414754'
  surface-tint: '#abc7ff'
  primary: '#abc7ff'
  on-primary: '#002f66'
  primary-container: '#448fff'
  on-primary-container: '#002859'
  inverse-primary: '#005cbb'
  secondary: '#d0bcff'
  on-secondary: '#3c0091'
  secondary-container: '#571bc1'
  on-secondary-container: '#c4abff'
  tertiary: '#ffaceb'
  on-tertiary: '#5d0056'
  tertiary-container: '#e951d5'
  on-tertiary-container: '#51004b'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d7e2ff'
  primary-fixed-dim: '#abc7ff'
  on-primary-fixed: '#001b3f'
  on-primary-fixed-variant: '#00458f'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#d0bcff'
  on-secondary-fixed: '#23005c'
  on-secondary-fixed-variant: '#5516be'
  tertiary-fixed: '#ffd7f2'
  tertiary-fixed-dim: '#ffaceb'
  on-tertiary-fixed: '#390034'
  on-tertiary-fixed-variant: '#830079'
  background: '#10131c'
  on-background: '#e0e2ef'
  surface-variant: '#32343f'
typography:
  headline-hero:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.03em
  headline-hero-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.025em
  title-screen:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.02em
  title-section:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.015em
  title-track:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: -0.01em
  body-default:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  metadata-supporting:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  caption-timestamp:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-pill:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.75rem
  margin: 1.25rem
  margin-compact: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.875rem
  space-lg: 1.25rem
  space-xl: 1.75rem
---

## Brand & Style

This design system defines an immersive, modern, and nocturnal mobile audio streaming experience. Designed primarily for mobile-first native and web applications (optimized around standard 390px viewports), the aesthetic merges modern digital minimalism with atmospheric, neon-tinged glassmorphism and deep-space container elevation.

The target audience consists of young, design-conscious audiophiles, digital natives, and casual listeners seeking a refined, club-like visual mood that recedes into the background, allowing album artwork, artist photography, and interactive media controls to command full attention. 

Key visual principles:
- **Atmospheric Depth:** Deep indigo-tinted blacks form the spatial horizon, completely avoiding pure neutral `#000000` to prevent visual harshness and OLED smearing while maintaining infinite spatial immersion.
- **Vibrant Linear Accents:** A signature tri-tone ultraviolet-to-fuchsia linear gradient acts as the energetic focal point across primary calls to action, player scrobblers, and featured badges.
- **Precision Micro-Details:** Delicate hairline 1px borders, subtle surface elevations, and tactile pill containers ground the floating media elements, ensuring tactile feedback and strict visual ergonomics.

## Colors

The color palette is built strictly around an obsidian-navy tonal foundation layered with luminous ultraviolet accents.

### Canvas & Surface Hierarchy
- **Canvas Base (`#080B14`):** The primary root viewport background. Deepest obsidian navy.
- **Grouped Section Background (`#0D1220`):** Secondary grouped layer used behind collection grids, nested drawers, and modal backdrops.
- **Elevated Surface (`#141B2D`):** Primary interactive card tier, song list items, bottom sheets, and mini-player containers.
- **Higher Surface Tier (`#1B2440`):** Elevated search bars, active filter pills, segmented controls, and button base layers.
- **Hairline Border Accent (`#1F2A48`):** 1px structural strokes used to delineate elevated cards, inputs, and row partitions.

### Accent & Dynamic Spectrum
- **Primary Brand Blue (`#2585FF`):** Dominant interactive state, active tab highlights, and gradient root.
- **Primary Brand Purple (`#8B5CF6`):** Secondary interactive transitions, featured genres, and central gradient midpoint.
- **Vibrant Fuchsia Pink (`#ED55D9`):** Accent highlights, favorited heart icons, and warm audio spectrum peaks.
- **Signature Aurora Gradient:** `linear-gradient(135deg, #2585FF 0%, #8B5CF6 50%, #ED55D9 100%)`, utilized for primary CTAs, active progress scrubbers, and hero badges.

### Typography & Functional Hues
- **Text Primary (`#F7F8FF`):** Maximum contrast white-tinted blue for song titles, hero headings, and active icon states.
- **Text Secondary (`#A2ABC3`):** Medium-contrast cool gray for artist subtitles, tab bar labels, and form placeholders.
- **Text Muted (`#6F7A96`):** Low-contrast gray for track durations, secondary counters, and inactive indicators.
- **System Feedback:** Success `#35D39A`, Warning `#F5B94C`, Destructive/Error `#FF5577`.

## Typography

The typographic hierarchy is engineered strictly with Inter to ensure clinical legibility against deep dark surfaces. 

Rules for implementation:
- **Optical Kerning & Tight Headings:** All display and screen titles apply negative tracking (`-0.01em` to `-0.03em`) to create a solid, impactful presence characteristic of contemporary streaming platforms.
- **Two-Line Metadata Caps:** Track titles on mobile cards and list rows must truncate cleanly at 1 line (`title-track`), paired directly below with artist and album credits set in `metadata-supporting`.
- **Numbers and Timers:** Time scrobblers (`01:42 / 03:24`) and track durations must utilize tabular numerical lining (`font-variant-numeric: tabular-nums`) to prevent horizontal jitter during real-time playback.

## Layout & Spacing

The layout is architected around a fluid 4-column mobile grid system based on a reference 390px viewport width, scaling up to an 8-column layout on tablets and 12-columns on desktop interfaces.

### Grid Rhythm & Viewport Bounds
- **Canvas Margins:** Standard mobile screens adopt a fixed horizontal padding of `1.25rem` (`20px`), reduced to `1rem` (`16px`) in compact edge-to-edge carousels.
- **Gutter Widths:** Content grids (e.g., genre tiles and playlist cards) maintain a consistent `0.75rem` (`12px`) or `1rem` (`16px`) gutter separation.
- **Horizontal Scroll Carousels:** Category rails and playlist collections break out of parent margins with `-1.25rem` bleeds, using `1.25rem` inset scroll padding so the initial element aligns flush with page content.
- **Persistent Bottom Shell:** Account for a standardized fixed `84px` combined mini-player + navigation dock container height with safe-area insets (`env(safe-area-inset-bottom)`) applied to base canvas scroll containers.

## Elevation & Depth

Visual hierarchy does not rely on traditional muddy drop shadows; instead, it is expressed through layered obsidian luminosity, specular hairline borders, and backdrop glass blurs.

### Elevation Levels
- **Tier 0 (Root Canvas - `#080B14`):** Passive view background containing subtle atmospheric linear gradient glows (`opacity: 0.15`) centered beneath prominent album artwork.
- **Tier 1 (Surface Containers - `#141B2D`):** Static cards and list rows. Defined by a 1px continuous hairline outline using `#1F2A48` without drop shadows.
- **Tier 2 (Floating & Interactive Controls - `#1B2440`):** Search bars, active pill chips, and bottom sheets. Employs a low-contrast ambient shadow: `box-shadow: 0 8px 24px -4px rgba(0, 0, 0, 0.5)`.
- **Tier 3 (Floating Mini-Player & Glass Docks):** Semi-translucent glass background (`rgba(20, 27, 45, 0.85)`) coupled with `backdrop-filter: blur(20px)` and an inner top border highlight of `1px solid rgba(255, 255, 255, 0.08)`.
- **Tier 4 (Hero Action Buttons & Active Scrubbers):** Primary CTA buttons and play buttons leverage glowing ambient diffusion: `box-shadow: 0 8px 20px -2px rgba(139, 92, 246, 0.4)`.

## Shapes

The design language balances structured soft rectangles for content containers with circular geometries for playback controls.

- **Album Art & Playlist Cards:** `16px` border-radius (`rounded-lg`), delivering soft, organic corners without clipping critical artwork information.
- **Input Fields & Search Bars:** `14px` border-radius to nest comfortably alongside 16px cards.
- **Filter Chips & Interactive Pills:** `9999px` full capsule radius (`rounded-full`) for high-speed scanning and thumb ergonomics.
- **Playback Control Buttons:** Primary circular elements (`48px` to `64px` diameter) use continuous `rounded-full` curvature to visually center play, pause, and skip triggers.

## Components

### Buttons & Interactive Triggers
- **Primary Hero Button:** Full capsule pill height (`48px`), styled with the signature 3-stop Aurora Gradient (`#2585FF` -> `#8B5CF6` -> `#ED55D9`). Text is high-contrast white `#F7F8FF`, weight `600`. Active press scale state: `transform: scale(0.98)`.
- **Secondary / Social Button:** `48px` height, surface background `#141B2D`, 1px border `#1F2A48`, text `#F7F8FF`. Includes centered 20px brand icon on the left edge.
- **Main Playback FAB:** `64px x 64px` circular button centered on player screens. White background `#FFFFFF` or Aurora gradient with `#080B14` or `#FFFFFF` icon, surrounded by an ambient purple glow.

### Cards & Media Tiles
- **Featured Hero Card:** Aspect ratio 16:9 or square with `16px` radius. Features dark vignette overlay on artwork bottoms (`linear-gradient(to top, rgba(8,11,20,0.9) 0%, transparent 60%)`) to ensure readability of overlaid titles and badges.
- **Grid Playlist Card:** Vertical stack consisting of a 1:1 aspect-ratio image container with `16px` radius, followed by an `8px` gap, a single-line `title-track` label, and a single-line `metadata-supporting` count.

### Track List Rows
- **List Item Container:** Minimum height `56px`, touch target `44px` padding minimum. Composed of a `44px x 44px` artwork thumbnail (`8px` radius), flex-grow title and subtitle stack, followed by duration timestamp and secondary `24px` icon button (`MoreVertical` or `Heart`).
- **Active / Playing State:** Track title text switches to `#2585FF` or `#ED55D9`, paired with an animated 3-bar equalizer micro-icon replacing the track number.

### Chips & Pills
- **Filter Chips:** Height `36px`, horizontal padding `16px`. Default state has surface `#141B2D` with border `#1F2A48` and text `#A2ABC3`. Active state switches to `#1B2440` with an active 1px gradient border or filled solid gradient with white text.

### Form Inputs & Search
- **Search Field:** Height `48px`, background `#1B2440`, radius `14px`, 1px border `#1F2A48`. Left-aligned 20px `Search` icon in `#6F7A96`. Text input in `#F7F8FF` with clear `X` trigger appearing dynamically on the right edge.

### Mini-Player & Bottom Navigation
- **Docked Mini-Player:** Height `56px`, docked directly above bottom tabs. Floats with `12px` lateral margins and `12px` radius over a blurred `#141B2D` surface. Includes a 2px micro progress bar pinned to the top edge rendered in the Aurora gradient.
- **Bottom Navigation Bar:** Fixed `60px` height container with 4 to 5 touch items (`Home`, `Search`, `Library`, `Profile`). Active item displays an active indicator dot or vibrant icon highlight in `#2585FF`.